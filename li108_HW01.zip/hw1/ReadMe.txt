The original images are
mountain.jpg and city.jpg

The each channel of the output is saved as
<image_name><Task number><channel_number>.jpg
For example, the first output channel of mountain.jpg from task 1 is saved as
mountainTask10.jpg

The output of Part B is saved as 
RunTimeVsOutputChannels.jpg
The x-axis is the log_2(number of output channels)
The y-axis is the runtime in seconds


